import pandas as pd
import random
import numpy as np
import matplotlib.pyplot as plt
import sqlite3
import ruptures as rpt
from datetime import datetime
import re
import csv
from io import StringIO
from ruptures.costs import CostL2
from sklearn.metrics.pairwise import rbf_kernel

df = pd.read_csv('unique_benchmarks.csv')

database_path = 'scraped_data_time.db'

# Connect to the database
conn = sqlite3.connect(database_path)
cursor = conn.cursor()

matching_entries = []

# While loop to ensure at least 20 matching entries
while len(matching_entries) < 30:
    # Randomly select one entry (row)
    # random_entry = df.sample(n=1)

    # Get the url
    # target_url = random_entry['Benchmark_URL'].iloc[0]
    target_url = "https://paperswithcode.com/sota/semantic-segmentation-on-ade20k"
    print(f"Target URL: {target_url}")

    # Write a query to select rows where the Benchmark_URL matches the target_url
    query = "SELECT * FROM datasets WHERE dataset_url = ?"

    # Execute the query with the target_url
    cursor.execute(query, (target_url,))

    # Fetch all matching rows
    matching_entries = cursor.fetchall()


'''
for i, metric in enumerate(matching_entries):
    print(i, metric)
'''

'''
# Check if there are any matching entries
if matching_entries:
    for entry in matching_entries:
        print(entry)
else:
    print("No matching entries found.")
'''

# Extract column names from the third element of the first entry
column_names_str = matching_entries[0][2]  # Extract column names from the second entry
# print(column_names_str)


# Split and strip the column names, and include columns starting from the first valid one
column_names = [col.replace('\n', '').strip() for col in column_names_str.split(',') if col.strip()]
print(f"The selected column names are: {column_names}")

# Find the index of "Date" to ensure we only include columns up to "Date"
if "Date" in column_names:
    end_index = column_names.index("Date") + 1
    column_names = column_names[:end_index]  # No need to worry about adding "Date" again

column_names.append('publication_time')

# List to store all the data rows
all_data = []

# Function to validate and convert the publication_time to datetime
def convert_to_date(date_str):
    if isinstance(date_str, str):
        # Clean the string by removing leading/trailing whitespace and "▼\n"
        cleaned_str = date_str.replace("▼\n", "").strip()
        date_time = pd.to_datetime(cleaned_str, format='%Y-%m-%d', errors='coerce')
        return date_time

# Regex to split by commas, but ignore commas inside parentheses
comma_split_regex = r',(?![^()]*\))'

# Loop through each entry in matching_entries to extract data
for entry in matching_entries:
    # Extract data from the appropriate element (index 3) in the tuple
    data_str = entry[3]  # Adjust index according to your data structure if needed

    # Split by commas outside of parentheses
    data = re.split(comma_split_regex, data_str)

    # Strip and clean each value
    data = [val.strip() for val in data]

    # Remove any trailing empty strings from the data list
    while data and not data[-1]:  # Remove trailing empty values
        data.pop()

    # Check if the length of data is greater than column_names
    if len(data) > len(column_names):
        # Truncate the data list to match the length of column_names - 1
        data = data[:len(column_names) - 1]
    elif len(data) < len(column_names) - 1:
        # Pad with None if data has fewer values than column_names - 1
        data += [None] * ((len(column_names) - 1) - len(data))

    # Append the data row to all_data list
    all_data.append(data)


# Now that all_data is ready, convert it to a pandas DataFrame
rank_year = pd.DataFrame(all_data, columns=column_names)


# Function to clean the 'Date' column and convert it to datetime
def clean_date(date_str):
    if isinstance(date_str, str):
        # Remove '▼\n' and strip leading/trailing whitespace
        cleaned_str = date_str.replace("▼\n", "").strip()
        # Convert to datetime
        return pd.to_datetime(cleaned_str, errors='coerce')
    return pd.NaT  # If the input is not a string, return NaT

# Apply the cleaning function to the 'Date' column
rank_year['publication_time'] = rank_year['Date'].apply(clean_date)

# Now inspect the updated DataFrame
print(rank_year[['Model', 'publication_time']].head())

'''
# Display the DataFrame
for index, row in df.head(2).iterrows():
    print(row)
'''

# Step 1: Ensure 'publication_time' column is properly converted to datetime
rank_year['publication_time'] = pd.to_datetime(rank_year['publication_time'], errors='coerce')

# Step 3: Select 'Model', 'publication_time', and the performance column (the third column in the dataset)
performance_column = rank_year.columns[1]  # Assuming the third column is performance
# print(performance_column)
selected_data = rank_year[['Model', 'publication_time', performance_column]]

# Step 4: Convert the performance column to numeric and handle non-numeric values
selected_data.loc[:, performance_column] = pd.to_numeric(selected_data[performance_column], errors='coerce')

# Check how many NaN values exist in the performance_column
num_nans = selected_data[performance_column].isna().sum()
print(f"Number of NaN values in {performance_column}: {num_nans}")

nan_rows = selected_data[selected_data[performance_column].isna()]
print(nan_rows)

# Step 2: Sort by the 'publication_time' column in ascending order
selected_data = selected_data.sort_values(by='publication_time', ascending=True)

# Assuming the best entry is the one with the highest performance
selected_data = selected_data.loc[selected_data.groupby('publication_time')[performance_column].idxmax()]

# Initialize an empty list to store the best observations
curr_best_observation = []

# Keep track of the current best performance
curr_best_performance = -float('inf')  # Start with the lowest possible performance

# Iterate over the sorted DataFrame (selected_data)
for index, row in selected_data.iterrows():
    performance_value = row[performance_column]

    # Check if the current model's performance is better than the current best
    if performance_value > curr_best_performance:
        # Update the current best performance
        curr_best_performance = performance_value

        # Add the current row to the best observations list
        curr_best_observation.append(row)

# Convert the best observations back to a DataFrame
curr_best_observation_df = pd.DataFrame(curr_best_observation)

# Display the current best observations
print("curr best observation")
print(curr_best_observation_df.shape)
print(curr_best_observation_df)

# Select the third column (index 2) as the performance column
performance_column = curr_best_observation_df.columns[2]

# Ensure there are enough data points
if len(curr_best_observation_df) < 10:  # Modify the threshold as necessary
    raise ValueError("Not enough data points for PELT algorithm.")

# Step 5: Apply the PELT algorithm to find change points in performance data
performance_data = curr_best_observation_df[performance_column].values

# Check if data has enough points for the PELT algorithm
if len(performance_data) < 2:
    raise ValueError("PELT requires at least two data points.")

# Initialize the PELT model
model = rpt.Pelt(model="l2").fit(performance_data)

# Define a penalty for the model (try different values if necessary)
penalty = 1  # Start with a low penalty value and adjust based on results

# Detect change points using the PELT algorithm
try:
    change_points = model.predict(pen=penalty)
except rpt.exceptions.BadSegmentationParameters:
    raise ValueError("PELT algorithm failed. Adjust the penalty or check the data.")

# Plot the performance data over time
plt.figure(figsize=(10, 6))

# Scatter plot of all performance data points (blue)
plt.scatter(selected_data['publication_time'], selected_data[performance_column], color='blue', label='All Models')

# Mark the change points (highlighted models)
highlighted_times = []
highlighted_performance = []
highlighted_labels = []

# Collect data for the highlighted models
for cp in change_points[:-1]:  # Exclude the last change point
    model_name = curr_best_observation_df['Model'].iloc[cp]  # Get the model name at the change point
    publication_time = curr_best_observation_df['publication_time'].iloc[cp]
    performance_value = curr_best_observation_df[performance_column].iloc[cp]

    # Check if publication_time is not NaT (valid datetime)
    if pd.notna(publication_time):
        highlighted_times.append(publication_time)
        highlighted_performance.append(performance_value)
        highlighted_labels.append(model_name)

# Scatter plot for change points (highlighted models) with larger red circles
# Use different markers for each model in the legend
for i in range(len(highlighted_times)):
    plt.scatter(highlighted_times[i], highlighted_performance[i], color='red', s=100,
                label=f'{highlighted_labels[i]} (Change Point)', zorder=5)

# Add legend to distinguish between all models and highlighted models
plt.legend()

# Add labels and title
plt.xlabel('Publication Time')
plt.ylabel('Benchmark Performance')
plt.title('Model Performance Over Time with Highlighted Change Points')
plt.grid(True)

# Show the plot
plt.show()

# Ensure the performance column is the third one
performance_column = selected_data.columns[2]  # This is the third column

# Step 1: Convert the performance column to a NumPy array (as required by ruptures)
performance_data = curr_best_observation_df[performance_column].values.reshape(-1, 1)  # Reshape to 2D array for kernel cost

# Step 2: Initialize the dynamic programming model with Gaussian kernel cost
kernel_cost = CostL2().fit(performance_data)
model = rpt.Dynp(custom_cost=kernel_cost, jump=1).fit(performance_data)

# Step 3: Detect change points using dynamic programming with Gaussian kernel
# Here, we specify the number of change points (n_bkps). Adjust based on your dataset.
n_bkps = 5  # Example: expecting 5 change points, adjust as needed
change_points = model.predict(n_bkps=n_bkps)

# Step 4: Plot the performance data over time
plt.figure(figsize=(10, 6))

# Scatter plot of all performance data points (blue)
plt.scatter(selected_data['publication_time'], selected_data[performance_column], color='blue', label='All Models')

# Mark the change points (highlighted models)
highlighted_times = []
highlighted_performance = []
highlighted_labels = []

# Collect data for the highlighted models
for cp in change_points[:-1]:  # Exclude the last change point (it refers to the end of the dataset)
    model_name = selected_data['Model'].iloc[cp]  # Get the model name at the change point
    publication_time = selected_data['publication_time'].iloc[cp]
    performance_value = selected_data[performance_column].iloc[cp]

    # Check if publication_time is not NaT (valid datetime)
    if pd.notna(publication_time):
        highlighted_times.append(publication_time)
        highlighted_performance.append(performance_value)
        highlighted_labels.append(model_name)

# Scatter plot for change points (highlighted models) with larger red circles
# Use different markers for each model in the legend
for i in range(len(highlighted_times)):
    plt.scatter(highlighted_times[i], highlighted_performance[i], color='red', s=100,
                label=f'{highlighted_labels[i]} (Change Point)', zorder=5)

# Add legend to distinguish between all models and highlighted models
plt.legend()

# Add labels and title
plt.xlabel('Publication Time')
plt.ylabel('Benchmark Performance')
plt.title('Model Performance Over Time with Change Points (Gaussian Kernel Dynamic Programming)')
plt.grid(True)

# Show the plot
plt.show()


# Ensure the performance column is the third one
performance_column = selected_data.columns[2]  # This is the third column

# Step 1: Convert the performance column to a NumPy array (as required by ruptures)
performance_data = curr_best_observation_df[performance_column].values.reshape(-1, 1)

# Step 2: Apply RBF kernel transformation to the data
# You can adjust gamma for the RBF kernel (higher values make it more sensitive to nearby points)
gamma = 0.1  # Adjust based on your data
transformed_data = rbf_kernel(performance_data, gamma=gamma)

# Step 3: Initialize the PELT model with L2 cost (since we transformed the data)
model = rpt.Pelt(model="l2").fit(transformed_data)

# Step 4: Detect change points using the PELT algorithm
penalty = 10  # Adjust based on your data
change_points = model.predict(pen=penalty)

# Step 5: Plot the performance data over time
plt.figure(figsize=(10, 6))

# Scatter plot of all performance data points (blue)
plt.scatter(selected_data['publication_time'], selected_data[performance_column], color='blue', label='All Models')

# Mark the change points (highlighted models)
highlighted_times = []
highlighted_performance = []
highlighted_labels = []

# Collect data for the highlighted models
for cp in change_points[:-1]:  # Exclude the last change point (it refers to the end of the dataset)
    model_name = selected_data['Model'].iloc[cp]  # Get the model name at the change point
    publication_time = selected_data['publication_time'].iloc[cp]
    performance_value = selected_data[performance_column].iloc[cp]

    # Check if publication_time is not NaT (valid datetime)
    if pd.notna(publication_time):
        highlighted_times.append(publication_time)
        highlighted_performance.append(performance_value)
        highlighted_labels.append(model_name)

# Scatter plot for change points (highlighted models) with larger red circles
for i in range(len(highlighted_times)):
    plt.scatter(highlighted_times[i], highlighted_performance[i], color='red', s=100,
                label=f'{highlighted_labels[i]} (Change Point)', zorder=5)

# Add legend to distinguish between all models and highlighted models
plt.legend()

# Add labels and title
plt.xlabel('Publication Time')
plt.ylabel('Benchmark Performance')
plt.title('Model Performance Over Time with RBF Kernel Change Points (PELT)')
plt.grid(True)

# Show the plot
plt.show()

conn.close()
