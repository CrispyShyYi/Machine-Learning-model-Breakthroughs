import pandas as pd

# Read final_result.csv into a DataFrame
df_final = pd.read_csv('final_result.csv')

# Read tasks_with_benchmarks_clean.csv into a DataFrame
df_tasks = pd.read_csv('tasks_with_benchmarks_clean.csv')

# Merge the DataFrames on 'Benchmark' and 'Benchmark_URL'
df_merged = pd.merge(
    df_tasks[['Benchmark_URL', 'Area', 'Task', 'Fallback_Name']],
    df_final,
    left_on='Benchmark_URL',
    right_on='Benchmark',
    how='right'
)

# Drop the 'Benchmark_URL' column if it's not needed
df_merged.drop(columns=['Benchmark_URL'], inplace=True)

# Reorder the columns to have df_tasks columns first
# List of df_tasks columns
tasks_columns = ['Area', 'Task', 'Fallback_Name']

# Updated list of df_final columns to include 'Performance'
final_columns = ['Benchmark', 'Model', 'Paper', 'Publication', 'Breakthrough', 'Performance']

# Ensure all columns exist in the DataFrame
all_columns = tasks_columns + final_columns
df_merged = df_merged[[col for col in all_columns if col in df_merged.columns]]

# Drop rows where 'Model', 'Paper', and 'Publication' are all None or NaN
df_merged = df_merged.dropna(subset=['Model', 'Paper', 'Publication'], how='all')

# Save the updated DataFrame to a new CSV file
df_merged.to_csv('final_result_updated.csv', index=False)

# Display the updated DataFrame
print(df_merged)
