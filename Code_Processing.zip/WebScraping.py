from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from selenium.common.exceptions import NoSuchElementException
import pandas as pd

# Step 1: Set up Selenium WebDriver
# Specify ChromeDriver version
chrome_driver_path = ChromeDriverManager("128.0.6613.120").install()

# Set up Chrome WebDriver using the specified ChromeDriver
driver = webdriver.Chrome(service=ChromeService(chrome_driver_path))
# Define the wait variable
wait = WebDriverWait(driver, 10)  # 10 seconds timeout

# Load the main page
driver.get("https://paperswithcode.com/sota")

# Step 2: Extract "Area" Names
areas = []
area_elements = wait.until(EC.presence_of_all_elements_located((By.CLASS_NAME, "task-group-title")))

for element in area_elements:
    area_name = element.find_element(By.TAG_NAME, 'a').text.strip()
    area_url = element.find_element(By.TAG_NAME, 'a').get_attribute('href')
    areas.append({'Area': area_name, 'Area_URL': area_url})

# Step 3: Extract "Task" Names
tasks = []
for area in areas:
    driver.get(area['Area_URL'])

    # Locate the container that holds all task sections
    container = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "div.container.content-buffer")))

    # Locate all rows that contain the task names
    task_containers = container.find_elements(By.CSS_SELECTOR, "div.infinite-container.featured-task > div.row")

    # Locate all 'sota-all-tasks' divs separately
    sota_all_tasks_divs = container.find_elements(By.CSS_SELECTOR, "div.sota-all-tasks")

    # Locate all 'card-deck card-break infinite-item' divs as a fallback option
    fallback_task_containers = container.find_elements(By.CSS_SELECTOR, "div.card-deck.card-break.infinite-item")

    # Make sure that the number of rows (task_containers) matches the number of 'sota-all-tasks' divs
    for i in range(min(len(task_containers), len(sota_all_tasks_divs))):

        # Extract the task name from the h2 tag in the current row
        task_name = task_containers[i].find_element(By.CSS_SELECTOR, "h2").text.strip()

        # Extract the URL from the corresponding 'sota-all-tasks' div
        task_url = None
        sota_all_tasks_div = sota_all_tasks_divs[i]
        try:
            task_url = sota_all_tasks_div.find_element(By.TAG_NAME, 'a').get_attribute('href')
        except NoSuchElementException:
            task_url = None  # Handle case where no URL is found in 'sota-all-tasks'

        # Append the task name and primary URL to the tasks list (if available)
        tasks.append({
            'Area': area['Area'],
            'Task': task_name,
            'Task_URL': task_url,  # Store the primary URL in one column
            'Fallback_URL': None,  # Initialize Fallback_URL as None initially
            'Fallback_Name': None  # Initialize Fallback_Name as None initially
        })

        # Fallback to 'card-deck card-break infinite-item' if no URL is found, and add each fallback URL directly
        if task_url is None:
            try:
                # Synchronize with the current fallback container
                fallback_div = fallback_task_containers[i]

                # Extract the fallback task name from 'col-xl-8 card-col card-col-title'
                fallback_name_elements = fallback_div.find_elements(By.CSS_SELECTOR,
                                                          "div.col-xl-8.card-col.card-col-title h1")

                # Extract all fallback URLs
                fallback_links = fallback_div.find_elements(By.TAG_NAME, 'a')  # Find all anchor tags
                # Ensure the number of names matches the number of links
                for name_element, link in zip(fallback_name_elements, fallback_links):
                    fallback_name = name_element.text.strip()  # Extract the text for each task name
                    fallback_url = link.get_attribute('href')  # Extract the URL for each link

                    # Append each fallback URL and name individually into the tasks list
                    tasks.append({
                        'Area': area['Area'],
                        'Task': task_name,  # The primary task name
                        'Task_URL': None,  # No primary URL available, hence None
                        'Fallback_URL': fallback_url,  # Store each fallback URL separately
                        'Fallback_Name': fallback_name  # Store the name of the fallback task
                    })
            except (NoSuchElementException, IndexError):
                continue  # If no fallback URLs are found, continue with the loop
'''
# Iterate through the tasks list to check for valid task URLs
for task in tasks:
    if task['Task_URL']:
        driver.get(task['Task_URL'])  # Navigate to the task URL

        # Wait for the 'infinite-container' to load that contains all cards
        try:
            infinite_container = wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "div.infinite-container.featured-task.area-tag-page"))
            )

            # Find all cards within this container
            card_divs = infinite_container.find_elements(By.CSS_SELECTOR, "div.card")

            # For each card, extract the URL from the <a> tag and the name from the <h1 class="card-title">
            for card in card_divs:
                try:
                    # Extract the URL from the <a> tag inside the card
                    card_url = card.find_element(By.TAG_NAME, 'a').get_attribute('href')

                    # Extract the task name from the <h1 class="card-title">
                    card_name = card.find_element(By.CSS_SELECTOR, "h1.card-title").text.strip()

                    # Append each card URL and name into the current task entry in the tasks list
                    tasks.append({
                        'Area': task['Area'],
                        'Task': task['Task'],
                        'Task_URL': task['Task_URL'],
                        'Subtask_URL': card_url,  # Store the card URL as Subtask_URL
                        'Subtask_Name': card_name  # Store the card title as Subtask_Name
                    })
                except NoSuchElementException:
                    continue  # If any element is missing, skip this card and continue

        except TimeoutException:
            # Handle cases where the task URL page doesn't load properly or doesn't contain the expected content
            continue
'''
'''
# Step 5: Extract "Dataset" Information
datasets = []
for subtask in subtasks:
    try:
        driver.get(subtask['Subtask_URL'])
        # Additional scraping code here
    except TimeoutException:
        print(f"Timeout occurred while accessing {subtask['Subtask_URL']}")
        continue
    try:
        # Wait until either the table or the "no data" message is present
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, 'benchmarks'))
        )

        # Check if the "no data" div is present
        no_data_div = driver.find_elements(By.CSS_SELECTOR, 'div.sota-no-sota')
        if no_data_div:
            continue  # Skip to the next subtask if no data is available

        # If data is present, locate the table
        table = driver.find_element(By.CSS_SELECTOR, 'div.sota-table-preview.table-responsive table')

        # Extract headers
        headers = [th.text.strip() for th in table.find_element(By.TAG_NAME, 'thead').find_elements(By.TAG_NAME, 'th')]

        # Extract rows
        for row in table.find_element(By.TAG_NAME, 'tbody').find_elements(By.TAG_NAME, 'tr'):
            # Find the first <td> element in the row and extract the <a> tag's href attribute
            first_td = row.find_element(By.TAG_NAME, 'td')
            a_tag = first_td.find_element(By.TAG_NAME, 'a')
            url = a_tag.get_attribute('href')

            data = [td.text.strip() for td in row.find_elements(By.TAG_NAME, 'td')]
            datasets.append({
                'Area': subtask['Area'],
                'Task': subtask['Task'],
                'Subtask': subtask['Subtask'],
                'Benchmark_URL': url,
                **dict(zip(headers, data))
            })

    except TimeoutException:
        continue  # Skip to the next subtask if timeout occurs
'''
'''
# Step 6: Extract "Benchmark" Information
benchmarks = []
for dataset in datasets:
    driver.get(dataset['Benchmark_URL'])  # Assuming you extract the URL for each benchmark
    benchmark_table = wait.until(
        EC.presence_of_element_located((By.CSS_SELECTOR, 'table.table-striped.show-overflow-x')))

    benchmark_headers = [th.text.strip() for th in benchmark_table.find_element(By.TAG_NAME, 'thead').find_elements(By.TAG_NAME, 'th')]
    for row in benchmark_table.find_element(By.TAG_NAME, 'tbody').find_elements(By.TAG_NAME, 'tr'):
        benchmark_data = [td.text.strip() for td in row.find_elements(By.TAG_NAME, 'td')]
        benchmarks.append({'Area': dataset['Area'], 'Task': dataset['Task'], 'Subtask': dataset['Subtask'],
                           **dict(zip(benchmark_headers, benchmark_data))})
'''
# Store the extracted data in a Pandas DataFrame
df_areas = pd.DataFrame(areas)
df_tasks = pd.DataFrame(tasks)
# df_subtasks = pd.DataFrame(subtasks)
# df_datasets = pd.DataFrame(datasets)
# df_benchmarks = pd.DataFrame(benchmarks)

# Save the data to CSV files for further analysis
df_areas.to_csv('areas.csv', index=False)
df_tasks.to_csv('tasks.csv', index=False)
# df_subtasks.to_csv('subtasks.csv', index=False)
# df_datasets.to_csv('datasets.csv', index=False)
# df_benchmarks.to_csv('benchmarks.csv', index=False)


# Close the WebDriver
driver.quit()

