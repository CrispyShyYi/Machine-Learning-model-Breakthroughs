from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from selenium.common.exceptions import NoSuchElementException
import pandas as pd

# Load the CSV file into a DataFrame
df_tasks = pd.read_csv('tasks_with_fallbacks.csv')

# Set up the Selenium WebDriver (make sure the path to ChromeDriver is correct)
chrome_driver_path = ChromeDriverManager("128.0.6613.120").install()
# Set up Chrome WebDriver using the specified ChromeDriver
driver = webdriver.Chrome(service=ChromeService(chrome_driver_path))
# Define the wait variable
wait = WebDriverWait(driver, 10)  # 10 seconds timeout

# Create a list to hold the new entries
new_rows = []

# Iterate over the DataFrame rows
for index, row in df_tasks.iterrows():
    if pd.notna(row['Fallback_URL']):  # Check if the Task_URL is not NaN
        try:
            driver.get(row['Fallback_URL'])  # Navigate to the Task_URL

            # Try to locate the table with class "benchmarksTable"
            try:
                benchmarks_table = driver.find_element(By.CSS_SELECTOR, 'div.sota-table-preview table#benchmarksTable')

                # Find all rows (<tr>) with onclick attributes inside the table body
                rows = benchmarks_table.find_elements(By.CSS_SELECTOR, 'tbody tr[onclick]')

                # Check if there are any rows and extract the first <a href="..."> for each entry
                for tr in rows:
                    try:
                        # Find the first <td> in the <tr>
                        first_td = tr.find_elements(By.CSS_SELECTOR, 'td')[0]  # Get the first <td>

                        # Find the first <a> inside the first <td>
                        first_url = first_td.find_element(By.CSS_SELECTOR, 'a').get_attribute('href')

                        # Create a new row with the benchmark URL
                        new_row = {
                            'Area': row['Area'],
                            'Task': row['Task'],
                            'Task_URL': row['Task_URL'],
                            'Fallback_Name': row['Fallback_Name'],
                            'Fallback_URL': row['Fallback_URL'],
                            'Benchmark_URL': first_url  # Store the first URL in the <td>
                        }
                        new_rows.append(new_row)

                    except (NoSuchElementException, IndexError):
                        # Handle case where no <td> or <a> is found inside the <tr>
                        new_row = {
                            'Area': row['Area'],
                            'Task': row['Task'],
                            'Task_URL': row['Task_URL'],
                            'Fallback_Name': row['Fallback_Name'],
                            'Fallback_URL': row['Fallback_URL'],
                            'Benchmark_URL': None  # No benchmark URL found
                        }
                        new_rows.append(new_row)

            except NoSuchElementException:
                # If the benchmarks table is not found, leave benchmark URL blank
                new_row = {
                    'Area': row['Area'],
                    'Task': row['Task'],
                    'Task_URL': row['Task_URL'],
                    'Fallback_Name': row['Fallback_Name'],
                    'Fallback_URL': row['Fallback_URL'],
                    'Benchmark_URL': None  # No benchmarksTable found
                }

            # Append the new row to the list
            new_rows.append(new_row)

        except TimeoutException:
            print(f"Timeout occurred for URL: {row['Task_URL']}")
            continue  # Skip to the next row if there's a timeout

# Create a DataFrame from the new rows
df_benchmarks = pd.DataFrame(new_rows)

# Save the modified DataFrame back to the CSV
df_benchmarks.to_csv('tasks_with_benchmarks.csv', index=False)

# Close the Selenium WebDriver
driver.quit()