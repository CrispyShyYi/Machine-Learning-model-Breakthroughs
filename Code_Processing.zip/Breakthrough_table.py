import pandas as pd
import numpy as np
import sqlite3
import re

df = pd.read_csv('unique_benchmarks.csv')

database_path = 'scraped_data_time.db'

# Connect to the database
conn = sqlite3.connect(database_path)
cursor = conn.cursor()

# Initialize an empty list to store the result rows
result_rows = []

# Function to make column names unique
from collections import Counter

def make_unique_column_names(column_names):
    counts = Counter()
    unique_names = []
    for col in column_names:
        counts[col] += 1
        if counts[col] > 1:
            unique_names.append(f"{col}_{counts[col]-1}")
        else:
            unique_names.append(col)
    return unique_names

# Create a list to store mismatched URLs
mismatched_urls = []

# Loop over each Benchmark_URL
for index, row in df.iterrows():
    Benchmark_URL = row['Benchmark_URL']
    Area = row['Area']
    Task = row['Task']
    Fallback_name = row['Fallback_Name']
    target_url = Benchmark_URL

    print(f"Processing Benchmark_URL: {target_url}")

    # Write a query to select rows where the Benchmark_URL matches the target_url
    query = "SELECT * FROM datasets WHERE dataset_url = ?"

    # Execute the query with the target_url
    cursor.execute(query, (target_url,))

    # Fetch all matching rows
    matching_entries = cursor.fetchall()

    # Check if the number of matching entries is less than 15
    if len(matching_entries) < 15:
        print(f"Less than 15 matching entries found for {target_url}. Skipping.")
        continue

    # If no matching entries, skip to next iteration
    if not matching_entries:
        print(f"No matching entries found for {target_url}. Skipping.")
        continue

    # Try to extract column names
    try:
        # Assuming matching_entries[0][2] contains your string
        column_names_str = matching_entries[0][2].strip()

        # Replace newline characters with a space
        column_names_str = column_names_str.replace('\n', ' ')

        # Split the string using '+' as the delimiter
        column_names = column_names_str.split('&^')

        # Remove empty strings and strip whitespace
        column_names = [col.strip() for col in column_names if col.strip()]

        print(f"The selected column names are: {column_names}")
    except Exception as e:
        print(f"Error extracting column names for {target_url}: {e}. Skipping.")
        continue

    # List to store all the data rows
    all_data = []

    # Loop through each entry in matching_entries to extract data
    for entry in matching_entries:
        expected_length = len(column_names)  # Dynamically set expected length based on column names

        # Extract data from the appropriate element (index 3) in the tuple
        data_str = entry[3].strip()  # Adjust index according to your data structure if needed

        # Replace newline characters with a space
        data_str = data_str.replace('\n', ' ')

        # Check if data_str starts with the delimiter and skip if it does
        if data_str.startswith('&^'):
            continue  # Skip the current entry
        else:
            # Split the data_str using '^' as the delimiter
            data = data_str.split('&^')

            # Strip whitespace from each value
            data = [val.strip() for val in data]
            print(f"the data is {data}")

        # Optionally handle missing or incomplete data
        if len(data) != expected_length:
            print(f"Warning: Data length {len(data)} does not match expected length {expected_length}")
            print(f"The extracted data is: {data}")

            # Add the mismatched Benchmark_URL to the list
            mismatched_urls.append(target_url)

            # Skip processing this URL
            print(f"Skipping {target_url} due to data mismatch.")
            break  # Break out of the inner loop and move to the next URL

        # Append the cleaned data row to all_data list
        all_data.append(data)

    # Now that all_data is ready, convert it to a pandas DataFrame
    rank_year = pd.DataFrame(all_data, columns=column_names)

    # Function to clean the 'Date' column and convert it to datetime
    def clean_date(date_str):
        if isinstance(date_str, str):
            # Remove '▼' and any non-numeric characters, including newlines and extra spaces
            cleaned_str = date_str.replace("▼", "").strip()

            # Convert to datetime
            return pd.to_datetime(cleaned_str, errors='coerce')

        return pd.NaT  # If the input is not a string, return NaT


    # Apply the cleaning function to the 'Date' column
    if 'Date' in rank_year.columns:
        rank_year['publication_time'] = rank_year['Date'].apply(clean_date)
    else:
        print(f"No 'Date' column in data for {target_url}. Skipping.")
        continue

    # Ensure 'publication_time' column is properly converted to datetime
    rank_year['publication_time'] = pd.to_datetime(rank_year['publication_time'], errors='coerce')

    # Print column names to check for duplicates
    print(f"Column names for {target_url}: {rank_year.columns.tolist()}")

    # Verify the performance column
    if 'Model' in rank_year.columns:
        # Identify possible performance columns (exclude 'Model', 'publication_time', 'Date', etc.)
        possible_perf_cols = [col for col in rank_year.columns if col not in ['Model', 'publication_time', 'Date', 'Paper Title']]
        if possible_perf_cols:
            performance_column = possible_perf_cols[0]  # Select the first possible performance column
            print(f"Using performance column: {performance_column}")
        else:
            print(f"No performance column found for {target_url}. Skipping.")
            continue
    else:
        print(f"'Model' column not found in data for {target_url}. Skipping.")
        continue

    # Function to rename duplicate column names by appending a suffix
    def rename_duplicates(columns):
        seen = {}
        new_columns = []
        for col in columns:
            if col in seen:
                # Increment the counter and rename the duplicated column
                seen[col] += 1
                new_columns.append(f"{col}_{seen[col]}")
            else:
                seen[col] = 0
                new_columns.append(col)
        return new_columns

    # Apply the renaming function to the columns of your DataFrame
    rank_year.columns = rename_duplicates(rank_year.columns)

    # Create a copy to avoid SettingWithCopyWarning
    selected_data = rank_year[['Model', 'publication_time', performance_column, 'Paper Title']].copy()

    # Remove '%' from the performance column if present
    selected_data[performance_column] = selected_data[performance_column].astype(str).str.replace('%', '', regex=True)

    # Convert the performance column to numeric and handle non-numeric values
    selected_data.loc[:, performance_column] = pd.to_numeric(selected_data[performance_column], errors='coerce')

    # Drop rows with NaN values in 'publication_time' or 'performance_column'
    selected_data = selected_data.dropna(subset=['publication_time', performance_column])

    # Sort by 'publication_time'
    selected_data = selected_data.sort_values(by='publication_time', ascending=True)


    # Now, find the curr_best_observation_df as in the code

    # Check if first performance is less than last performance to determine if higher is better
    if selected_data.empty:
        print(f"No valid data after cleaning for {target_url}. Skipping.")
        continue

    first_performance = selected_data[performance_column].iloc[0]
    last_performance = selected_data[performance_column].iloc[-1]

    if first_performance < last_performance:
        # Higher is better
        selected_data = selected_data.loc[selected_data.groupby('publication_time')[performance_column].idxmax()]

        # Initialize an empty list to store the best observations
        curr_best_observation = []

        # Keep track of the current best performance
        curr_best_performance = -float('inf')  # Start with the lowest possible performance

        # Iterate over the sorted DataFrame (selected_data) to find the best observations
        for index_sd, row_sd in selected_data.iterrows():
            performance_value = row_sd[performance_column]

            # Check if the current model's performance is better than the current best
            if performance_value > curr_best_performance:
                # Update the current best performance
                curr_best_performance = performance_value

                # Add the current row to the best observations list
                curr_best_observation.append(row_sd)

        # Convert the best observations back to a DataFrame
        curr_best_observation_df = pd.DataFrame(curr_best_observation)
    else:
        # Lower is better
        selected_data = selected_data.loc[selected_data.groupby('publication_time')[performance_column].idxmin()]

        # Initialize an empty list to store the least observations
        curr_best_observation = []

        # Keep track of the current least performance
        curr_best_performance = float('inf')  # Start with the highest possible performance

        # Iterate over the sorted DataFrame (selected_data) to find the least observations
        for index_sd, row_sd in selected_data.iterrows():
            performance_value = row_sd[performance_column]

            # Check if the current model's performance is worse than the current best
            if performance_value < curr_best_performance:
                # Update the current least performance
                curr_best_performance = performance_value

                # Add the current row to the best observations list
                curr_best_observation.append(row_sd)

        # Convert the least observations back to a DataFrame
        curr_best_observation_df = pd.DataFrame(curr_best_observation)

    # Check the number of rows in curr_best_observation_df
    if curr_best_observation_df.shape[0] < 5:
        print(f"Less than 5 observations in curr_best_observation_df for {target_url}. Skipping.")
        continue

    # Now proceed with Method 3
    print(f"Processing Method 3 for {target_url}")

    # Method 3: Calculate the slope change rate
    last_column = pd.to_numeric(curr_best_observation_df[performance_column], errors='coerce')

    # Calculate slopes between consecutive points
    time_column = pd.to_datetime(curr_best_observation_df['publication_time'], errors='coerce')

    # Convert time differences to a numeric format (e.g., days)
    time_diff_in_days = time_column.diff().dt.total_seconds() / (60 * 60 * 24)

    # Now calculate the slope using the time difference in days
    curr_best_observation_df['slope'] = abs(last_column.diff()) / time_diff_in_days

    # Calculate change rate of slope between consecutive slopes
    curr_best_observation_df['slope_change_rate'] = (
        abs(curr_best_observation_df['slope'].diff()) / abs(curr_best_observation_df['slope'].shift(1))
    )

    # Remove infinite or NaN values resulting from division by zero or other issues
    curr_best_observation_df = curr_best_observation_df.replace([np.inf, -np.inf], np.nan)
    curr_best_observation_df = curr_best_observation_df.dropna(subset=['slope_change_rate'])

    # If after this there is no data, skip
    if curr_best_observation_df.empty:
        print(f"No valid slope_change_rate data for {target_url}. Skipping.")
        continue

    # Extract top 15% points based on 'slope_change_rate'
    top_15_percent_threshold = curr_best_observation_df['slope_change_rate'].quantile(0.7)
    top_15_percent_points = curr_best_observation_df[curr_best_observation_df['slope_change_rate'] >= top_15_percent_threshold]

    # If top_15_percent_points is empty, skip
    if top_15_percent_points.empty:
        print(f"No top 15% points found for {target_url}. Skipping.")
        continue

    # Collect model names from 'top_15_percent_points'
    model_names = top_15_percent_points['Model'].tolist()
    model_paper = top_15_percent_points['Paper Title'].tolist()

    model_names_str = ','.join(model_names)
    model_paper_str = ','.join(model_paper)

    # Append the data to result_rows
    result_row = {
        'Area': Area,
        'Task': Task,
        'Fallback_name': Fallback_name,
        'Benchmark_URL': Benchmark_URL,
        'Model_Names': model_names_str,
        'Model_Paper': model_paper
    }

    # check the results
    # print(result_row)

    result_rows.append(result_row)

# After processing all Benchmark_URLs, create a DataFrame from result_rows
result_df = pd.DataFrame(result_rows)

# Save result_df to a CSV file
result_df.to_csv('top_15_percent_models.csv', index=False)

# Close the database connection
conn.close()

# Print the result_df
print("Processing complete")

print("mismatched_urls = [")
for url in mismatched_urls:
    print(f"  {url},")
print("]")
