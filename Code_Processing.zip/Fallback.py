.from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
import pandas as pd

# Specify ChromeDriver version
chrome_driver_path = ChromeDriverManager("128.0.6613.120").install()

# Set up Chrome WebDriver using the specified ChromeDriver
driver = webdriver.Chrome(service=ChromeService(chrome_driver_path))
# Define the wait variable
wait = WebDriverWait(driver, 10)  # 10 seconds timeout

# Create a list to hold the new entries
new_rows = []

df_tasks = pd.read_csv('tasks2.csv')

# Iterate over the DataFrame rows
for index, row in df_tasks.iterrows():
    if pd.notna(row['Task_URL']):  # Check if the Task_URL is not NaN
        try:
            driver.get(row['Task_URL'])  # Navigate to the Task_URL

            # Wait for the container with cards to load
            infinite_container = wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "div.infinite-container.featured-task.area-tag-page"))
            )

            # Find all cards inside the container
            card_divs = infinite_container.find_elements(By.CSS_SELECTOR, "div.card")

            # Extract URL and Name from each card
            for card in card_divs:
                try:
                    card_url = card.find_element(By.TAG_NAME, 'a').get_attribute('href')
                    card_name = card.find_element(By.CSS_SELECTOR, "h1.card-title").text.strip()

                    # If the row already has a Fallback entry, keep it as is
                    if pd.notna(row['Fallback_Name']) and pd.notna(row['Fallback_URL']):
                        # If a Fallback_Name and Fallback_URL exist, skip adding a new row for that entry.
                        continue

                    # Otherwise, create a new row for the found subtask
                    new_row = {
                        'Area': row['Area'],
                        'Task': row['Task'],
                        'Task_URL': row['Task_URL'],
                        'Fallback_Name': card_name,
                        'Fallback_URL': card_url
                    }
                    new_rows.append(new_row)

                except NoSuchElementException:
                    continue  # Skip if any element is missing

        except TimeoutException:
            print(f"Timeout occurred for URL: {row['Task_URL']}")
            continue  # Skip to the next row if there's a timeout

# Create a DataFrame from the new rows and concatenate it with the original DataFrame
df_fallbacks = pd.DataFrame(new_rows)

# Concatenate the original tasks DataFrame with the new fallback tasks
df_final = pd.concat([df_tasks, df_fallbacks], ignore_index=True)

# Remove rows where Fallback_URL is empty or NaN
df_final_cleaned = df_final.dropna(subset=['Fallback_URL'])

# Save the modified DataFrame back to the CSV
df_final_cleaned.to_csv('tasks_with_fallbacks.csv', index=False)

# Close the Selenium WebDriver
driver.quit()
