import pandas as pd
import random
import numpy as np
import matplotlib.pyplot as plt
import sqlite3
import ruptures as rpt
from datetime import datetime
import re
import csv
from adjustText import adjust_text


df = pd.read_csv('unique_benchmarks.csv')

database_path = 'scraped_data_time.db'

# Connect to the database
conn = sqlite3.connect(database_path)
cursor = conn.cursor()

matching_entries = []

# test url
# target_url = "https://paperswithcode.com/sota/semantic-segmentation-on-ade20k"
# target_url = "https://paperswithcode.com/sota/semantic-segmentation-on-ade20k-val"
# target_url = "https://paperswithcode.com/sota/object-detection-on-coco-o"
# target_url = 'https://paperswithcode.com/sota/language-modelling-on-wikitext-103'
# target_url = 'https://paperswithcode.com/sota/medical-image-segmentation-on-synapse-multi'
# target_url = 'https://paperswithcode.com/sota/visual-reasoning-on-nlvr2-dev'
target_url = 'https://paperswithcode.com/sota/video-question-answering-on-msrvtt-qa'
# print(f"Target URL: {target_url}")

# Write a query to select rows where the Benchmark_URL matches the target_url
query = "SELECT * FROM datasets WHERE dataset_url = ?"

# Execute the query with the target_url
cursor.execute(query, (target_url,))

# Fetch all matching rows
matching_entries = cursor.fetchall()

# Ensure there are matching entries
if not matching_entries:
    print("No matching entries found for the target URL.")
    conn.close()
    exit()

# Extract column names from the third element of the first entry
column_names_str = matching_entries[0][2].strip()
column_names = column_names_str.split('&^')
column_names = [col.strip() for col in column_names if col.strip()]

print(f"The selected column names are: {column_names}")

# List to store all the data rows
all_data = []

# Loop through each entry in matching_entries to extract data
for entry in matching_entries:
    expected_length = len(column_names)
    data_str = entry[3].strip()
    data = data_str.split('&^')
    data = [val.strip() for val in data]

    if len(data) != expected_length:
        print(f"Warning: Data length {len(data)} does not match expected length {expected_length}")
        continue  # Skip entries with mismatched data length

    print(f"The extracted data is: {data}")
    all_data.append(data)

# Convert all_data to a pandas DataFrame
rank_year = pd.DataFrame(all_data, columns=column_names)

# Function to clean the 'Date' column and convert it to datetime
def clean_date(date_str):
    if isinstance(date_str, str):
        cleaned_str = date_str.replace("▼\n", "").strip()
        return pd.to_datetime(cleaned_str, errors='coerce')
    return pd.NaT

# Apply the cleaning function to the 'Date' column
rank_year['publication_time'] = rank_year['Date'].apply(clean_date)

# Ensure 'publication_time' column is properly converted to datetime
rank_year['publication_time'] = pd.to_datetime(rank_year['publication_time'], errors='coerce')

# Select 'Model', 'publication_time', and the performance column
performance_column = rank_year.columns[1]  # Adjust if needed
selected_data = rank_year[['Model', 'publication_time', performance_column]]

# Remove percentage signs and other non-numeric characters from the performance column
selected_data[performance_column] = selected_data[performance_column].str.replace('%', '', regex=True)
selected_data[performance_column] = selected_data[performance_column].str.extract('(\d+\.?\d*)', expand=False)

# Convert the performance column to numeric and handle non-numeric values
selected_data[performance_column] = pd.to_numeric(selected_data[performance_column], errors='coerce')

# Drop rows with NaN values in 'publication_time' or 'performance_column'
selected_data.dropna(subset=['publication_time', performance_column], inplace=True)

# Sort by 'publication_time' in ascending order
selected_data.sort_values(by='publication_time', ascending=True, inplace=True)

# Determine if higher performance values are better
first_performance = selected_data[performance_column].iloc[0]
last_performance = selected_data[performance_column].iloc[-1]

if first_performance < last_performance:
    higher_is_better = True
    selected_data = selected_data.loc[selected_data.groupby('publication_time')[performance_column].idxmax()]
    curr_best_observation = []
    curr_best_performance = -float('inf')

    for index, row in selected_data.iterrows():
        performance_value = row[performance_column]
        if performance_value > curr_best_performance:
            curr_best_performance = performance_value
            curr_best_observation.append(row)

else:
    higher_is_better = False
    selected_data = selected_data.loc[selected_data.groupby('publication_time')[performance_column].idxmin()]
    curr_best_observation = []
    curr_best_performance = float('inf')

    for index, row in selected_data.iterrows():
        performance_value = row[performance_column]
        if performance_value < curr_best_performance:
            curr_best_performance = performance_value
            curr_best_observation.append(row)

# Convert the best observations back to a DataFrame
curr_best_observation_df = pd.DataFrame(curr_best_observation)
print("Current best observations:")
print(curr_best_observation_df)

# Calculate the slope and slope change rate using original performance data
print("\nCalculating slope and slope change rate...")
last_column = curr_best_observation_df[performance_column]
time_column = curr_best_observation_df['publication_time']

# Calculate time differences in days
time_diff_in_days = time_column.diff().dt.total_seconds() / (60 * 60 * 24)

# Handle zero or negative time differences to avoid division by zero or negative slopes
time_diff_in_days.replace(0, np.nan, inplace=True)

curr_best_observation_df['slope'] = abs(last_column.diff()) / time_diff_in_days

# Calculate change rate of slope between consecutive slopes
curr_best_observation_df['slope_change_rate'] = (
    abs(curr_best_observation_df['slope'].diff()) / abs(curr_best_observation_df['slope'].shift(1))
)

# Clean up infinite or NaN values
curr_best_observation_df.replace([np.inf, -np.inf], np.nan, inplace=True)
curr_best_observation_df.dropna(subset=['slope_change_rate'], inplace=True)

# Normalize the slope change rate after calculation
min_slope_change_rate = curr_best_observation_df['slope_change_rate'].min()
max_slope_change_rate = curr_best_observation_df['slope_change_rate'].max()

if max_slope_change_rate != min_slope_change_rate:
    curr_best_observation_df['normalized_slope_change_rate'] = (
        curr_best_observation_df['slope_change_rate'] - min_slope_change_rate
    ) / (max_slope_change_rate - min_slope_change_rate)
else:
    curr_best_observation_df['normalized_slope_change_rate'] = 0

# Extract top 15% points based on 'normalized_slope_change_rate'
top_15_percent_threshold = curr_best_observation_df['normalized_slope_change_rate'].quantile(0.7)
top_15_percent_points = curr_best_observation_df[
    curr_best_observation_df['normalized_slope_change_rate'] >= top_15_percent_threshold
]
# Filter the top points to keep only those with slope_change_rate > 0.01
top_15_percent_points = top_15_percent_points[top_15_percent_points['slope_change_rate'] > 0.01]

# Check if there are any points left after filtering
if top_15_percent_points.empty:
    print("No top points with slope_change_rate greater than 0.01 found.")
else:
    print("Top points after filtering:")
    print(top_15_percent_points)

# Plotting
plt.figure(figsize=(12, 6))
plt.scatter(curr_best_observation_df['publication_time'], curr_best_observation_df['normalized_slope_change_rate'],
            label="All Points", color='blue', alpha=0.5)
plt.scatter(top_15_percent_points['publication_time'], top_15_percent_points['normalized_slope_change_rate'],
            color='red', label="Top 15% Normalized Slope Change Rate", alpha=0.8)

# Annotate the model names for the top 15% points
texts = []
for i, row in top_15_percent_points.iterrows():
    texts.append(plt.text(
        row['publication_time'], row['normalized_slope_change_rate'], row['Model'],
        fontsize=8, ha='right', va='bottom'
    ))

adjust_text(texts, arrowprops=dict(arrowstyle='-', color='gray', lw=0.5))

# Adding labels and title
plt.xlabel("Publication Time")
plt.ylabel("Normalized Slope Change Rate")
plt.title("Normalized Slope Change Rate Over Time with Top 15% Highlighted")

# Adjust the legend position
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))

plt.tight_layout()
plt.show()

# Display the final DataFrame
print("\nFinal DataFrame with slope and normalized slope change rate:")
print(curr_best_observation_df)

# Close the database connection
conn.close()