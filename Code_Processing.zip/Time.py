import sqlite3
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import pandas as pd

# Connect with dp file to scrape more accurate time data
database_path = 'scraped_data3.db'

chrome_driver_path = ChromeDriverManager().install()
driver = webdriver.Chrome(service=ChromeService(chrome_driver_path))
# Define the wait variable
wait = WebDriverWait(driver, 10)  # 10 seconds timeout

# Step1: Connect to the database
conn = sqlite3.connect(database_path)
cur = conn.cursor()

# Step 2: Add the publication_time column to the datasets table if it doesn't already exist
try:
    cur.execute('ALTER TABLE datasets ADD COLUMN publication_time TEXT')
    conn.commit()
    print("Added 'publication_time' column.")
except sqlite3.OperationalError:
    # This will happen if the column already exists, so we just pass
    print("'publication_time' column already exists.")

# Step 3: Fetch all paper_url from the datasets table
cur.execute('SELECT paper_url FROM datasets')
entries = cur.fetchall()

# Step 4: Function to scrape the time from the paper URL
def scrape_time(paper_url):
    try:
        driver.get(paper_url)  # Navigate to the paper page
        # Find the first <span class="author-span"> under <p> inside <div class="authors">
        time_element = driver.find_element(By.CSS_SELECTOR, 'div.authors > p > span.author-span')
        publication_time = time_element.text.strip()
        return publication_time
    except TimeoutException:
        print(f"Timeout while trying to load {paper_url}")
        return None
    except Exception as e:
        print(f"Error occurred while processing {paper_url}: {e}")
        return None

# Step 5: Iterate over each entry, extract the time, and update the new column in the database
for entry in entries:  # 'entries' is a list of tuples, so we unpack each tuple
    paper_url = entry[0]  # Extract the paper_url from the tuple

    if paper_url and paper_url != 'N/A':  # Skip invalid or missing URLs
        publication_time = scrape_time(paper_url)  # Scrape the time from the URL
        if publication_time:
            # Update the new 'publication_time' column in the SQLite database
            cur.execute('UPDATE datasets SET publication_time = ? WHERE paper_url = ?', (publication_time, paper_url))
            conn.commit()

# Close the driver and database connection
driver.quit()
conn.close()