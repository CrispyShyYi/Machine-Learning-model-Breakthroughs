import sqlite3
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import pandas as pd
from selenium.webdriver.support import expected_conditions as EC


# Load the CSV file into a DataFrame
df_tasks = pd.read_csv('unique_benchmarks.csv')

# Extract only the URLs from the "Benchmark_URL" column
benchmark_urls = df_tasks['Benchmark_URL']  # Assuming the column name is exactly "Benchmark_URL"

chrome_driver_path = ChromeDriverManager().install()
driver = webdriver.Chrome(service=ChromeService(chrome_driver_path))
# Define the wait variable
wait = WebDriverWait(driver, 10)  # 10 seconds timeout

# Step 1: Create a connection to SQLite database (this creates 'scraped_data.db' if it doesn't exist)
conn = sqlite3.connect('scraped_data_time1.db')
cur = conn.cursor()

# Create a table to store datasets
cur.execute('''
CREATE TABLE IF NOT EXISTS datasets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dataset_url TEXT,
    column_name TEXT,
    data TEXT,
    UNIQUE (dataset_url, data)
)
''')

def login():
    # Navigate to the login page
    login_url = "https://paperswithcode.com/sota/semantic-segmentation-on-ade20k"
    driver.get(login_url)

    try:
        # Find the div with class 'login-modal-message'
        login_modal = driver.find_element(By.CLASS_NAME, 'login-modal-message')

        # Find the first <a> inside this div
        login_link = login_modal.find_element(By.TAG_NAME, 'a')

        # Get the href of the login link
        login_url = login_link.get_attribute('href')
        print(f"Login URL found: {login_url}")

        # Navigate to the login URL
        driver.get(login_url)

        # Step 2: Login process
        username_field = driver.find_element(By.ID, 'id_username')
        password_field = driver.find_element(By.ID, 'id_password')
        print("Login required. Logging in now.")

        # Perform login
        username_field.send_keys('CrispyAlfred')  # Replace with actual username
        password_field.send_keys('116456090601_Wjl')  # Replace with actual password

        login_button = driver.find_element(By.ID, 'login-btn')  # Replace with actual login button ID
        login_button.click()

        print("Login successful.")
    except Exception as e:
        print("Error during login process:", e)

# Function to scrape a webpage using Selenium
def scrape_data(url):
    print(f"Scraping data from {url}")

    # Navigate to the webpage
    driver.get(url)

    # Step 1: Store the URL separately
    dataset_url = url

    try:
        edit_button = wait.until(EC.element_to_be_clickable((By.ID, 'evaluation-table-edit-button')))
        driver.execute_script("arguments[0].click();", edit_button)  # Use JavaScript to click
        print("Edit button clicked via JavaScript.")
    except TimeoutException:
        print("Edit button not found or not clickable.")
        return

    # Step 2: Ensure the table is visible by clicking the 'Leaderboard' tab
    leaderboard_tab = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'a[data-bs-target="#leaderboard"]')))
    leaderboard_tab.click()

    # Wait for the table to be visible
    wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, 'table.htCore')))

    # Step 3: Get column names from the table header
    column_elements = driver.find_elements(By.CSS_SELECTOR, 'table.htCore thead tr th')

    # Extract the text from each column header
    columns = [th.text.strip() for th in column_elements]

    # Print or process the column headers
    print(f"Columns: {columns}")

    # Step 4: Get data rows from the table
    rows = []
    row_elements = driver.find_elements(By.CSS_SELECTOR, 'tbody tr')

    for tr in row_elements:
        # Extract text from each <td> element in the row
        row_data = [td.text.strip() for td in tr.find_elements(By.CSS_SELECTOR, 'td')]

        # Skip empty rows (optional)
        if any(row_data):  # Check if there is any non-empty data in the row
            rows.append(row_data)

    # Print the number of rows and actual data
    print(f"Total rows scraped: {len(rows)}")
    for row in rows:
        print(row)

    return dataset_url, columns, rows

# Step 4: Insert data into SQLite
def insert_data(dataset_url, columns, rows):
    separator = '+'  # Your chosen separator
    for row in rows:
        # Insert the row data into the dataset
        cur.execute('INSERT INTO datasets (dataset_url, column_name, data) VALUES (?, ?, ?)',
                    (dataset_url, separator.join(columns), separator.join(row)))
    conn.commit()


# Example usage of the modified script
# benchmark_urls = ['https://paperswithcode.com/sota/semantic-segmentation-on-ade20k']


# log in first
login()

# Scrape data
for url in benchmark_urls:
    # Check if the URL is not empty and starts with "http" or "https"
    if pd.notna(url):
        try:
            dataset_url, columns, rows = scrape_data(url)
            insert_data(dataset_url, columns, rows)
        except TimeoutException:
            print(f"Timeout while trying to load {url}")
        except Exception as e:
            print(f"Error occurred while processing {url}: {e}")
    else:
        print(f"Invalid URL skipped: {url}")

# Close the driver and SQLite connection
driver.quit()
conn.close()
