import pandas as pd
import numpy as np

# Read the data
df = pd.read_csv('final_result_updated.csv')

# Convert 'Publication' column to datetime
df['Publication'] = pd.to_datetime(df['Publication'], errors='coerce')

# Initialize the 'Breakthrough' column with default value 0
df['Breakthrough'] = 0

# Handle non-numeric performance values
performance_col = 'Performance'  # Adjust this if your performance column has a different name

# Remove non-numeric characters like '%' from the 'Performance' column
df[performance_col] = df[performance_col].astype(str).str.replace(r'[^\d\.\-]+', '', regex=True)

# Convert the 'Performance' column to numeric
df[performance_col] = pd.to_numeric(df[performance_col], errors='coerce')

# Drop rows with NaN values in 'Performance' or 'Publication'
df.dropna(subset=[performance_col, 'Publication'], inplace=True)

# Group the DataFrame by 'Area', 'Task', and 'Benchmark'
for (area, task, benchmark), group in df.groupby(['Area', 'Task', 'Benchmark']):
    print(f"Processing Area: {area}, Task: {task}, Benchmark: {benchmark}")

    # Ensure that the group is sorted by 'Publication' date
    group = group.sort_values(by='Publication', ascending=True)

    # Determine if higher performance values are better
    first_performance = group[performance_col].iloc[0]
    last_performance = group[performance_col].iloc[-1]
    higher_is_better = first_performance < last_performance

    # Find the best observations over time
    if higher_is_better:
        best_group = group.loc[group.groupby('Publication')[performance_col].idxmax()]
    else:
        best_group = group.loc[group.groupby('Publication')[performance_col].idxmin()]

    best_group.dropna(inplace=True)
    if best_group.empty:
        print(f"No valid observations for Area {area}, Task {task}, Benchmark {benchmark}. Skipping.")
        continue

    curr_best_performance = -float('inf') if higher_is_better else float('inf')
    curr_best_indices = []

    for idx_row, row in best_group.iterrows():
        performance_value = row[performance_col]
        if (higher_is_better and performance_value > curr_best_performance) or \
           (not higher_is_better and performance_value < curr_best_performance):
            curr_best_performance = performance_value
            curr_best_indices.append(idx_row)

    curr_best_observation_df = best_group.loc[curr_best_indices]

    if curr_best_observation_df.shape[0] < 5:
        print(f"Less than 5 observations for Area {area}, Task {task}, Benchmark {benchmark}. Skipping.")
        continue

    last_column = curr_best_observation_df[performance_col]
    time_column = curr_best_observation_df['Publication']
    time_diff_in_days = time_column.diff().dt.total_seconds() / (60 * 60 * 24)
    time_diff_in_days.replace(0, np.nan, inplace=True)
    curr_best_observation_df['slope'] = abs(last_column.diff()) / time_diff_in_days
    curr_best_observation_df['slope_change_rate'] = (
        abs(curr_best_observation_df['slope'].diff()) / abs(curr_best_observation_df['slope'].shift(1))
    )
    curr_best_observation_df.replace([np.inf, -np.inf], np.nan, inplace=True)
    curr_best_observation_df.dropna(subset=['slope_change_rate'], inplace=True)

    if curr_best_observation_df.empty:
        print(f"No valid slope change rate data for Area {area}, Task {task}, Benchmark {benchmark}. Skipping.")
        continue

    min_slope_change_rate = curr_best_observation_df['slope_change_rate'].min()
    max_slope_change_rate = curr_best_observation_df['slope_change_rate'].max()

    if max_slope_change_rate == min_slope_change_rate:
        curr_best_observation_df['normalized_slope_change_rate'] = 0
    else:
        curr_best_observation_df['normalized_slope_change_rate'] = (
            curr_best_observation_df['slope_change_rate'] - min_slope_change_rate
        ) / (max_slope_change_rate - min_slope_change_rate)

    top_15_percent_threshold = curr_best_observation_df['normalized_slope_change_rate'].quantile(0.7)
    top_15_percent_points = curr_best_observation_df[
        curr_best_observation_df['normalized_slope_change_rate'] >= top_15_percent_threshold
    ]

    for idx, row in top_15_percent_points.iterrows():
        if row['slope_change_rate'] > 0.01:
            df.loc[idx, 'Breakthrough'] = 1

# Drop duplicate rows based on all columns
df.drop_duplicates(inplace=True)

# Save the updated DataFrame back to CSV
df.to_csv('final_result_updated.csv', index=False)

print("Processing complete.")
