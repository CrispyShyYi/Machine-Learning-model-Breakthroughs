import pandas as pd
import sqlite3

database_path = 'scraped_data_time.db'

# Connect to the database
conn = sqlite3.connect(database_path)
cursor = conn.cursor()

# Initialize an empty list to store the result rows
result_rows = []

# Get the table names
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()

# Assuming the table we need is the first one (adjust if necessary)
table_name = tables[0][0]

# Get the column names
cursor.execute(f"PRAGMA table_info({table_name});")
columns_info = cursor.fetchall()
column_names = [col[1] for col in columns_info]

first_column = column_names[1]
last_column = column_names[-1]

# Select the first and last columns (adding ROWID to maintain order)
cursor.execute(f"SELECT ROWID, {first_column}, {last_column} FROM {table_name}")
rows = cursor.fetchall()

for row in rows:
    row_id = row[0]
    first_col_value = row[1]
    last_col_value = row[2]

    # Clean '\n' and '▼' from the last column
    if last_col_value:
        last_col_value = last_col_value.replace('\n', '').replace('▼', '')
        # Split by '&^'
        split_values = last_col_value.split('&^')
        # Strip whitespace and replace empty strings with None
        split_values = [value.strip() if value.strip() != '' else None for value in split_values]
        # Get Model, Performance, Paper, Publication
        if len(split_values) >= 4:
            selected_indices = [split_values[0], split_values[1], split_values[-2], split_values[-1]]
        elif len(split_values) == 3:
            selected_indices = [split_values[0], split_values[1], split_values[2], None]
        elif len(split_values) == 2:
            selected_indices = [split_values[0], split_values[1], None, None]
        elif len(split_values) == 1:
            selected_indices = [split_values[0], None, None, None]
        else:
            selected_indices = [None, None, None, None]
    else:
        selected_indices = [None, None, None, None]

    # Combine row_id, first_col_value, selected_indices, and breakthrough = 0
    result_row = [row_id, first_col_value] + selected_indices + [0]
    # Append to result_rows
    result_rows.append(result_row)

# Define column names for the result
result_column_names = ['RowID', 'Benchmark', 'Model', 'Performance', 'Paper', 'Publication', 'Breakthrough']

# Create DataFrame
df = pd.DataFrame(result_rows, columns=result_column_names)

# Replace empty strings with NaN (pd.NA)
df.replace('', pd.NA, inplace=True)

# Drop rows where 'Model', 'Paper', and 'Publication' are all None or NaN
df = df.dropna(subset=['Model', 'Paper', 'Publication'], how='all')

# Sort by 'RowID' to ensure original order is preserved
df.sort_values(by='RowID', inplace=True)

# Drop 'RowID' column if it's not needed in the final output
df.drop(columns=['RowID'], inplace=True)

# Export to CSV
df.to_csv('final_result.csv', index=False)

# Close the database connection
conn.close()

# Display the DataFrame
print(df)
